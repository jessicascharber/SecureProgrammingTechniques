namespace Mod5Lab
{
    public class Utility
    {
       public static byte[] GetBytes(string str) {
           return System.Text.Encoding.Default.GetBytes(str);
       } 

       public static string GetString(byte[] b_array) {
           return System.Text.Encoding.Default.GetString(b_array);
       }
    }
}