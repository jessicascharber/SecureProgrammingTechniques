using System;
namespace Mod2Lab
{
    public class customException : Exception
    {
        public customException() {

        }
        public customException(string message) : base(message) {
            
        }
        public customException(string message, Exception inner) : base(message, inner) {
            
        }    
    }
}